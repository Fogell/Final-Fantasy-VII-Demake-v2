/*
 * Program: Final Fantasy VII Demake
 * This: AutoTurret.java
 * Author: S. Tealbey
 * Date: 4/26/2016
 * Purpose: To create a class for Auto Turret
 */
package pkgfinal.fantasy.vii.demake;

/**
 *
 * @author setht
 */
public class AutoTurret extends Map
{
    int enemyHP = 50;
    String choice;
    
    public void fight()
    {
        
        enemyHP = 50;
        
        System.out.println("You encoutered an Auto Turret!");
        playerHP = finalPlayerHP; 
        while(playerHP > 0 && enemyHP > 0)
        {
            System.out.println("Your HP:" + playerHP + "\n"
                    + "What will you do:\n"
                    + "A)ttack\n"
                    + "H)eal\n"
                    + "L)imit\n");
            choice = input.next();
            
            switch(choice)
            {
                case "A":
                case "a":
                    dealDamage();
                    break;
                        
                case "H":
                case "h":
                    cure();
                    break;
                
                case "L":
                case "l":
                    limit();
                    break;
                
                default:
                    System.out.println("What?");
                    System.out.println();
                    break;
            }
            enemyAttack();
        }
        if(enemyHP <= 0)
        {
            System.out.println();
            System.out.println("You are victorious!");
            System.out.println();
        }
        else if(playerHP <= 0)
        {
            System.out.println();
            System.out.println("Perished...");
            System.out.println();
            while(choice != "Y" && choice != "y" && choice != "N" && choice != "n")
            {
                System.out.println("Play Agian?\n"
                        + "Y)es\n"
                        + "N)o");
                choice = input.next();
                
                switch(choice)
                {
                    case "Y":
                    case "y":
                        restart();
                        break;
                    
                    case "N":
                    case "n":
                        System.exit(0);
                        break;
                    
                    default:
                        System.out.println("Invalid input, please try again.");
                }
            }
        }
    }
    public void dealDamage()
    {
        int damage = (int)(Math.random() * 25);
        enemyHP = enemyHP - damage;
        System.out.println("You dealt " + damage + " to the Auto Turret.");
        damage = 0;
    }
    
    public void cure()
    {
        int heal = 10 + (int)(Math.random() * (50 - 10));
        playerHP = playerHP + heal;
        if(playerHP > 250)
        {
            playerHP = 250;
        }
        System.out.println("You gained " + heal + " HP.");
        heal = 0;
    }
    
    public void limit()
    {
        if(limit >= 100)
        {
            int specialDamage = 100 + (int)(Math.random() * (200 - 100));
            enemyHP = enemyHP - specialDamage;
            System.out.println("By using you signature move, Braver, you deal " + specialDamage);
            specialDamage = 0;
            limit = 0;
        }
        else
        {
            System.out.println("You aren't ready for that yet...");
        }
    }
    
    public void enemyAttack()
    {
        int turretAttack = (int) (Math.random() * 2);
        if(turretAttack >= 1)
        {
            int enemyDamage = (int) (Math.random() * 15);
            int limitGain = (int) (Math.random() * 10);
            playerHP = playerHP - enemyDamage;
            limit = limit + limitGain;
            System.out.println("Auto Turret shot for " + enemyDamage + " damage.");
            enemyDamage = 0;
        
            if(limit >= 100)
            {
                System.out.println("Limit Break now obtainable!");
            }
            else
            {

            }
        }
        else
        {
            System.out.println("Auto Turret: Target Lost!");
        }
    }
}
