/*
 * Program: Final Fantasy VII Demake
 * This: FinalFantasyVIIDemake.java
 * Author: S. Tealbey
 * Date: 4/26/2016
 * Purpose: To create a text based RPG based on Final Fantasy VII
 */
package pkgfinal.fantasy.vii.demake;
import java.util.Scanner;

public class FinalFantasyVIIDemake 
{
    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        Map Midgar = new Map();
        Marine guard = new Marine();
        AutoTurret bot = new AutoTurret();
        String start;
//===================================Intro======================================        
        System.out.println("                          1111111111\n"
                         + "               1      11111111\n"
                         + "  11111  11      111111111\n"
                         + "11   11111111111111111\n"
                         + "1   111 111111111\n"
                         + "1111111111\n"
                         + "  11111");
        System.out.println();
        System.out.println("Final Fantasy VII Demake");
        System.out.println();
        System.out.println("Created by Seth Tealbey");
        System.out.println();
        System.out.println("Mission Briefing:\n"
                + "Shinra Corp is building reactors all across Midgar and are sucking\n"
                + "the all of the mako, a resource essential to life on the planet,\n"
                + "out of the lifestream. It is up to you, Cloud, and your \n"
                + "companions, Barret, Tifa, Jessie, Biggs, and Wedge to destroy one\n"
                + "such reactor.\n"
                + "\n"
                + "Press any key to start.\n");
        start = input.next();
        Midgar.play();
    }
}
