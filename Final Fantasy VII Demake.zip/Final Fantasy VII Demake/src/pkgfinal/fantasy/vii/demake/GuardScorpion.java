/*
 * Program: Final Fantasy VII Demake
 * This: GuardScorpion.java
 * Author: S. Tealbey
 * Date: 4/26/2016
 * Purpose: To create a class for Guard Scorpion
 */
package pkgfinal.fantasy.vii.demake;

public class GuardScorpion extends Map
{
    int enemyHP = 500;
    String choice;
    
    public void fight()
    {
        enemyHP = 500;
        System.out.println("The mighty mechanical Guard Scorpion has arrived!");
        while(playerHP > 0 && enemyHP > 0)
        {
            System.out.println("Your HP:" + playerHP + "\n"
                    + "What will you do:\n"
                    + "A)ttack\n"
                    + "H)eal\n"
                    + "L)imit\n");
            choice = input.next();
            
            switch(choice)
            {
                case "A":
                case "a":
                    dealDamage();
                    break;
                        
                case "H":
                case "h":
                    cure();
                    break;
                
                case "L":
                case "l":
                    limit();
                    break;
                
                default:
                    System.out.println("What?");
                    System.out.println();
                    break;
            }
            enemyAttack();
        }
        if(enemyHP <= 0)
        {
            System.out.println();
            System.out.println("You are victorious!");
        }
        else if(playerHP <= 0)
        {
            System.out.println();
            System.out.println("Perished...");
            System.out.println();
            while(choice != "Y" && choice != "y" && choice != "N" && choice != "n")
            {
                System.out.println("Play Agian?\n"
                        + "Y)es\n"
                        + "N)o");
                choice = input.next();
                
                switch(choice)
                {
                    case "Y":
                    case "y":
                        restart();
                        break;
                    
                    case "N":
                    case "n":
                        System.exit(0);
                        break;
                    
                    default:
                        System.out.println("Invalid input, please try again.");
                }
            }
        }
    }
    public void dealDamage()
    {
        int damage = (int)(Math.random() * 25);
        enemyHP = enemyHP - damage;
        System.out.println("You dealt " + damage + " to the Guard Scorpion.");
        damage = 0;
    }
    
    public void cure()
    {
        int heal = 10 + (int)(Math.random() * (50 - 10));
        playerHP = playerHP + heal;
        if(playerHP > 250)
        {
            playerHP = 250;
        }
        System.out.println("You gained " + heal + " HP.");
        heal = 0;
    }
    
    public void limit()
    {
        if(limit >= 100)
        {
            int specialDamage = 100 + (int)(Math.random() * (200 - 100));
            enemyHP = enemyHP - specialDamage;
            System.out.println("By using you signature move, Braver, you deal " + specialDamage);
            specialDamage = 0;
            limit = 0;
        }
        else
        {
            System.out.println("You aren't ready for that yet...");
        }
    }
    
    public void enemyAttack()
    {
        int bossAttack = (int)(Math.random() * 9);
        if(bossAttack >= 0 && bossAttack < 3)
        {
            rifle();
        }
        else if(bossAttack >= 3 && bossAttack < 9)
        {
            scorpionTail();
        }
        else if(bossAttack == 9)
        {
            tailLaser();
        }
    }
    
    public void rifle()
    {
        int enemyDamage = (int) (Math.random() * 25);
        int limitGain = (int) (Math.random() * 10);
        playerHP = playerHP - enemyDamage;
        limit = limit + limitGain;
        System.out.println("Guard Scorpion uses rifle, deals " + enemyDamage + " damage.");
        enemyDamage = 0;
        
        if(limit >= 100)
        {
            System.out.println("Limit Break now obtainable!");
        }
        else
        {
            
        }
    }
    
    public void scorpionTail()
    {
        int enemyDamage = (int) (Math.random() * 15);
        int limitGain = (int) (Math.random() * 10);
        playerHP = playerHP - enemyDamage;
        limit = limit + limitGain;
        System.out.println("Guard Scorpion uses Scorpion Tail, deals " + enemyDamage + " damage.");
        enemyDamage = 0;
        
        if(limit >= 100)
        {
            System.out.println("Limit Break now obtainable!");
        }
        else
        {
            
        }
    }
    
    public void tailLaser()
    {
        int enemyDamage = 35 + (int) (Math.random() * (50 - 35));
        int limitGain = (int) (Math.random() * 30);
        playerHP = playerHP - enemyDamage;
        limit = limit + limitGain;
        System.out.println("Guard Scorpion uses the devasting Tail Laser, deals " + enemyDamage + " damage.");
        enemyDamage = 0;
        
        if(limit >= 100)
        {
            System.out.println("Limit Break now obtainable!");
        }
        else
        {
            
        }
    }
}
