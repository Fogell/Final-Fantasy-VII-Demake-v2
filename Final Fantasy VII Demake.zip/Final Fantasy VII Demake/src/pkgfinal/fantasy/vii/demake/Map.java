/*
 * Program: Final Fantasy VII Demake
 * This: Map.java
 * Author: S. Tealbey
 * Date: 4/26/2016
 * Purpose: To create a class for the map
 */
package pkgfinal.fantasy.vii.demake;
import java.util.Scanner;

public class Map extends FinalFantasyVIIDemake
{
    int playerHP = 250;
    int finalPlayerHP = playerHP;
    int limit = 0;
    String progression;
    String choice;
    Scanner input = new Scanner(System.in);
    
    public void play()
    {
        Marine guard = new Marine();
        AutoTurret bot = new AutoTurret();
        GuardScorpion mech = new GuardScorpion();
        
        System.out.println("As the train pulls up to the platform at the base of the reactor,\n"
                         + "you notice a few guards standing there, waiting for the supposed\n"
                         + "payload on the train. Little do they know, you and your comrades\n"
                         + "are on the train. You see Barrett jump out of the train, taking a\n"
                         + "guard by complete surprise before gunning him down. Just as the\n"
                         + "other guards realize what is going on, you and the rest of the party\n"
                         + "attack, and a brief skirmish ensues.\n"
                         + "\n"
                         + "Tifa: Behind you!\n"
                         + "\n"
                         + "Press any key to continue");
        progression = input.next();
        guard.fight();
        
        System.out.println("Barrett: Alright, that takes care of them, let's move out!");
        System.out.println("Biggs, Wedge, and Jessie: Yes sir!");
        System.out.println();
        
        while(choice != "G" && choice != "g" && choice != "S" && choice != "s")
        {
            System.out.println("What will you do?\n"
                             + "G)o with them\n"
                             + "S)tay at the train");
            choice = input.next();

            switch(choice)
            {    
                case "G":
                case "g":
                    System.out.println("You enter a room with a big metal door, must be\n"
                                     + "the entrance to the reatactor. You see Jessie \n"
                                     + "tampering with the control panel off to the side\n"
                                     + "of the door.\n"
                                     + "\n"
                                     + "Jessie: Almost got it... There we go.\n"
                                     + "\n"
                                     + "The door opens.\n"
                                     + "\n"
                                     + "Jessie: Shall we?\n"
                                     + "\n"
                                     + "You walk into the room, and once you are in the middle\n"
                                     + "of the room, an alarm goes off and the door closes\n"
                                     + "\n"
                                     + "Biggs: Hang on, we've got company.\n"
                                     + "\n"
                                     + "Press any key to continue");
                    progression = input.next();
                    playerHP = finalPlayerHP;
                    bot.fight();
                    System.out.println("Wedge: Guards incoming!\n"
                                     + "\n"
                                     + "Press any key to continue");
                    progression = input.next();
                    finalPlayerHP = playerHP;
                    guard.fight();
                    playerHP = finalPlayerHP;
                    System.out.println("Barrett: There will be more of them, no doubt.\n"
                                     + "Come on fools, lets get to the elevator over there!");
                    System.out.println();
                    choice = "";
                    while(choice != "G" && choice != "g" && choice != "W" && choice != "w" && choice != "R" && choice != "r")
                    {
                        System.out.println("What will you do?\n"
                                         + "G)o to the elevator\n"
                                         + "W)ait\n"
                                         + "R)etrun to the train");
                        choice = input.next();
                        switch(choice)
                        {
                            case "G":
                            case "g":
                                System.out.println("You enter the elevator with your comrades\n"
                                                 + "and Barrett tries to strike up a conversation\n"
                                                 + "with you.\n"
                                                 + "\n"
                                                 + "Barrett: So what's your name, rookie?");
                                choice = "";
                                while(choice != "I" && choice != "i" && choice != "D" && choice != "d")
                                {
                                    System.out.println("How will respond?\n"
                                                     + "I)'m Cloud.\n"
                                                     + "D)on't say anything");
                                    choice = input.next();
                                    switch(choice)
                                    {
                                        case "I":
                                        case "i":
                                            System.out.println("Cloud: I'm Cloud.");
                                            System.out.println("Barrett: Cloud, huh? Well then, Cloud, we will be reaching the reactor room soon,\n"
                                                             + "what you need to do is set up the bomb so that this infernal shall no longer mess\n"
                                                             + "with the lifestream.\n"
                                                             + "\n"
                                                             + "Cloud: You don't need to lecture me about the lifestream, it is none of\n"
                                                             + "my concern.\n"
                                                             + "\n"
                                                             + "Barrett:...\n"
                                                             + "\n"
                                                             + "Jessie: We're here, let's go!\n"
                                                             + "\n"
                                                             + "Press any key to continue");
                                            progression = input.next();
                                            System.out.println("You enter a room that has a long bridge leading to the core of the reactor. As you\n"
                                                             + "approach the reactor, you hear a large mechanical rumbling sound, doesn't sound good\n"
                                                             + "\n"
                                                             + "Barrett: Cloud, watch out!\n"
                                                             + "\n"
                                                             + "Press any key to continue");
                                            progression = input.next();
                                            mech.fight();
                                            System.out.println("After you have defeated the Gargantuan Guard Scorpion, you plant the explosives to take out\n"
                                                             + "the reactor. Minutes after rushing out of the building, the bomb detonates and the reactor is\n"
                                                             + "destroyed. After this, you and your comrades go to Tifa's Bar called 'The Seventh Heaven', and\n"
                                                             + "celebrate your victory!\n"
                                                             + "\n"
                                                             + "Created by: Seth Tealbey\n"
                                                             + "Inspired by Final Fantasy VII and Final Fantasy VII Remake by Square Enix\n"
                                                             + "Thank you for playing!");
                                            System.out.println();
                                            while(choice != "Y" && choice != "y" && choice != "N" && choice != "n")
                                            {
                                                System.out.println("Play Agian?\n"
                                                        + "Y)es\n"
                                                        + "N)o");
                                                choice = input.next();

                                                switch(choice)
                                                {
                                                    case "Y":
                                                    case "y":
                                                        restart();
                                                        break;

                                                    case "N":
                                                    case "n":
                                                        System.exit(0);
                                                        break;

                                                    default:
                                                        System.out.println("Invalid input, please try again.");
                                                }
                                            }
                                            break;
                                        
                                        case "D":
                                        case "d":
                                            System.out.println("Cloud:...");
                                            System.out.println();
                                            System.out.println("Barret: Oh, so you're one of those people, huh?\n"
                                                             + "\n"
                                                             + "Tifa: His name is Cloud.\n"
                                                             + "\n"
                                                             + "Barrett: Cloud, huh? Well then, Cloud, we will be reaching the reactor room soon,\n"
                                                             + "what you need to do is set up the bomb so that this infernal shall no longer mess\n"
                                                             + "with the lifestream.\n"
                                                             + "\n"
                                                             + "Cloud: You don't need to lecture me about the lifestream, it is none of\n"
                                                             + "my concern.\n"
                                                             + "\n"
                                                             + "Barrett:...\n"
                                                             + "\n"
                                                             + "Jessie: We're here, let's go!\n"
                                                             + "\n"
                                                             + "Press any key to continue");
                                            progression = input.next();
                                            System.out.println("You enter a room that has a long bridge leading to the core of the reactor. As you\n"
                                                             + "approach the reactor, you hear a large mechanical rumbling sound, doesn't sound good\n"
                                                             + "\n"
                                                             + "Barrett: Cloud, watch out!\n"
                                                             + "\n"
                                                             + "Press any key to continue");
                                            progression = input.next();
                                            mech.fight();
                                            System.out.println("After you have defeated the Gargantuan Guard Scorpion, you plant the explosives to take out\n"
                                                             + "the reactor. Minutes after rushing out of the building, the bomb detonates and the reactor is\n"
                                                             + "destroyed. After this, you and your comrades go to Tifa's Bar called 'The Seventh Heaven', and\n"
                                                             + "celebrate your victory!\n"
                                                             + "\n"
                                                             + "Barrett: Definitely one of those people..."
                                                             + "\n"
                                                             + "Created by: Seth Tealbey\n"
                                                             + "Inspired by Final Fantasy VII and Final Fantasy VII Remake by Square Enix\n"
                                                             + "Thank you for playing!\n");
                                            System.out.println();
                                            while(choice != "Y" && choice != "y" && choice != "N" && choice != "n")
                                            {
                                                System.out.println("Play Agian?\n"
                                                        + "Y)es\n"
                                                        + "N)o");
                                                choice = input.next();

                                                switch(choice)
                                                {
                                                    case "Y":
                                                    case "y":
                                                        restart();
                                                        break;

                                                    case "N":
                                                    case "n":
                                                        System.exit(0);
                                                        break;

                                                    default:
                                                        System.out.println("Invalid input, please try again.");
                                                }
                                            }
                                            break;
                                        default:
                                            System.out.println("Barrett: Yo, try speaking English!");
                                            System.out.println();
                                            System.out.println("Press any key to continue");
                                            input.next();
                                            break;
                                    }
                                }
                                break;
                            
                            case "W":
                            case "w":
                                System.out.println("Biggs: Got more turrets!\n"
                                                 + "\n"
                                                 + "Press any key to continue");
                                progression = input.next();
                                finalPlayerHP = playerHP;
                                bot.fight();
                                playerHP = finalPlayerHP;
                                System.out.println("Biggs: Probably shouldn't stick around for much longer.\n"
                                        + "");
                                System.out.println("Press any key to continue.");
                                input.next();
                                break;
                            
                            case "R":
                            case "r":
                                System.out.println("Tifa: Please don't abandon us, Cloud!");
                                System.out.println();
                                System.out.println("Press any key to continue");
                                input.next();
                                break;
                            default:
                                System.out.println("Barrett: Yo, try speaking English!");
                                System.out.println();
                                System.out.println("Press any key to continue");
                                input.next();
                                break;
                        }
                    }
                    break;

                case "S":
                case "s":
                    System.out.println("Barrett: That means you too, rookie!");
                    System.out.println();
                    System.out.println("Press any key to continue");
                    input.next();
                    break;

                default:
                    System.out.println("Barrett: Yo, try speaking English!");
                    System.out.println();
                    System.out.println("Press any key to continue");
                    input.next();
                    break;
            }
        }
    }
    public void restart()
    {
        play();
    }
}
